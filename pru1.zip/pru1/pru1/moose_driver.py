import rclpy
from geometry_msgs.msg import Twist

HALF_DISTANCE_BETWEEN_WHEELS = 0.045
WHEEL_RADIUS = 0.025

class MooseDriver:
    def __init__(self, webots_node, properties):
            self.__robot = webots_node.robot

            self.__names = ["left motor 1",  "left motor 2",  "left motor 3",  "left motor 4",
            "right motor 1", "right motor 2", "right motor 3", "right motor 4"]
            

            self.__motors=[]
            #get motor tags
            for i in range(0,8):
                self.__motors.append(self.__robot.getDevice(self.__names[i]))
                self.__motors[i].setPosition(float('inf'))
                self.__motors[i].setVelocity(0)

            self.__target_twist = Twist()

            rclpy.init(args=None)
            self.__node = rclpy.create_node('moose_driver')
            self.__node.create_subscription(Twist, 'cmd_vel', self.__cmd_vel_callback, 1)

    def __cmd_vel_callback(self, twist):
        # Recibe las posiciones de las articulaciones y las almacena en una variable
        self.__target_twist = twist
        print('Received command velocity message:', twist)

    def step(self):
        rclpy.spin_once(self.__node, timeout_sec=0)

        forward_speed = self.__target_twist.linear.x
        angular_speed = self.__target_twist.angular.z

        command_motor_left = (forward_speed - angular_speed * HALF_DISTANCE_BETWEEN_WHEELS) / WHEEL_RADIUS
        command_motor_right = (forward_speed + angular_speed * HALF_DISTANCE_BETWEEN_WHEELS) / WHEEL_RADIUS
        print('Left motors: ', command_motor_left, 'Right motors: ', command_motor_right)
        for i in range(0,4):
            self.__motors[i].setVelocity(command_motor_left)
            self.__motors[i+4].setVelocity(command_motor_right)
        



