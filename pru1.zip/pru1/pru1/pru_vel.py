import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range
from geometry_msgs.msg import Twist



class PruVel(Node):
    def __init__(self):
        super().__init__('pru_vel')

        self.__publisher = self.create_publisher(Twist, 'cmd_vel', 1)

    def run(self):
        rate = self.create_rate(10)  # 10 Hz
        while rclpy.ok():
            command_message = Twist()
            command_message.linear.x = 0.1

            self.__publisher.publish(command_message)
            print('Sended command velocity message:', command_message)
            rate.sleep()

        
    
def main(args=None):
    rclpy.init(args=args)
    avoider = PruVel()
    avoider.run()
    rclpy.spin(avoider)
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    avoider.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()